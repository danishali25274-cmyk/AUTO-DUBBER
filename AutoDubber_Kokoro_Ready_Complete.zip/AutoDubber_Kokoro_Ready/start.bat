@echo off
setlocal
cd /d "%~dp0"
title Auto Dubber
if not exist ".venv\Scripts\python.exe" (
  echo Auto Dubber is not installed yet. Run install.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe app.py
if errorlevel 1 (
  echo.
  echo Auto Dubber closed with an error. Read the message above.
  pause
)
