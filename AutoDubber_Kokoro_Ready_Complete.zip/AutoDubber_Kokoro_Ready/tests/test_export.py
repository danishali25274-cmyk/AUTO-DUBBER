import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import app


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "FFmpeg is required")
class ExportIntegrationTests(unittest.TestCase):
    def test_exports_dub_for_video_without_original_audio(self):
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp)
            video = project / "source_silent.mp4"
            voice = project / "english_voice.wav"
            subprocess.run([
                "ffmpeg", "-y", "-f", "lavfi", "-i",
                "color=c=blue:s=320x240:r=25:d=2", "-an", "-c:v", "libx264",
                "-pix_fmt", "yuv420p", str(video),
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run([
                "ffmpeg", "-y", "-f", "lavfi", "-i", "sine=frequency=440:duration=0.6",
                "-ar", "24000", "-ac", "1", str(voice),
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            segment = {
                "start": 0.5, "end": 1.5, "dur": app.media_duration(voice),
                "pace": 1.0, "file": str(voice),
            }
            output = app.mix_and_export(video, [segment], None, project, lambda _msg: None)

            self.assertTrue(output.is_file())
            self.assertGreater(output.stat().st_size, 1000)
            self.assertAlmostEqual(app.media_duration(output), 2.0, delta=0.15)
            audio_codec = subprocess.run([
                "ffprobe", "-v", "error", "-select_streams", "a:0",
                "-show_entries", "stream=codec_name", "-of", "default=nw=1:nk=1",
                str(output),
            ], check=True, capture_output=True, text=True).stdout.strip()
            self.assertEqual(audio_codec, "aac")


if __name__ == "__main__":
    unittest.main()
