import importlib.util
import unittest
from pathlib import Path
from types import SimpleNamespace

APP_PATH = Path(__file__).resolve().parents[1] / "app.py"
SPEC = importlib.util.spec_from_file_location("autodubber_app", APP_PATH)
APP = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(APP)


class SentenceTempoTests(unittest.TestCase):
    def test_normal_line_keeps_normal_speed(self):
        tempo, slot = APP.sentence_tempo({"start": 0, "end": 4, "dur": 2, "pace": 1.0})
        self.assertAlmostEqual(tempo, 1.0)
        self.assertAlmostEqual(slot, 3.97)

    def test_fast_original_line_speeds_up_english(self):
        tempo, _ = APP.sentence_tempo({"start": 0, "end": 4, "dur": 2, "pace": 1.3})
        self.assertAlmostEqual(tempo, 1.3)

    def test_slow_original_line_slows_down_english(self):
        tempo, _ = APP.sentence_tempo({"start": 0, "end": 4, "dur": 2, "pace": 0.8})
        self.assertAlmostEqual(tempo, 0.8)

    def test_fit_requirement_prevents_overrun_up_to_limit(self):
        tempo, _ = APP.sentence_tempo({"start": 0, "end": 2, "dur": 3, "pace": 0.8})
        self.assertAlmostEqual(tempo, 3 / 1.97)

    def test_pace_is_clamped_to_natural_range(self):
        tempo, _ = APP.sentence_tempo({"start": 0, "end": 5, "dur": 1, "pace": 4.0})
        self.assertAlmostEqual(tempo, 1.6)


class TimedPhraseTests(unittest.TestCase):
    def test_long_silence_splits_phrases_and_keeps_gap(self):
        words = [
            SimpleNamespace(start=0.10, end=0.30, word=" Hello"),
            SimpleNamespace(start=0.32, end=0.50, word=" there."),
            SimpleNamespace(start=1.20, end=1.45, word=" How"),
            SimpleNamespace(start=1.47, end=1.70, word=" are you?"),
        ]
        source = SimpleNamespace(start=0.10, end=1.70, text="Hello there. How are you?", words=words)
        result = APP.build_timed_segments([source])
        self.assertEqual([item["text"] for item in result], ["Hello there.", "How are you?"])
        self.assertGreater(result[1]["start"] - result[0]["end"], 0.6)

    def test_missing_word_timestamps_uses_whisper_segment(self):
        source = SimpleNamespace(start=1.0, end=2.5, text="Fallback phrase.", words=None)
        result = APP.build_timed_segments([source])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["text"], "Fallback phrase.")
        self.assertEqual(result[0]["pace"], 1.0)


if __name__ == "__main__":
    unittest.main()
