@echo off
setlocal
cd /d "%~dp0"
title Auto Dubber - Setup

echo ========================================
echo       Auto Dubber - First-time setup
echo ========================================

where py >nul 2>nul
if errorlevel 1 goto install_python
py -3.12 --version >nul 2>nul
if errorlevel 1 goto install_python

goto check_ffmpeg

:install_python
echo Python 3.12 was not found.
where winget >nul 2>nul
if errorlevel 1 (
  echo ERROR: winget is unavailable. Install Python 3.12 from python.org, then run this file again.
  pause
  exit /b 1
)
echo Installing Python 3.12 with winget...
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
  echo ERROR: Python installation failed. Install Python 3.12 manually and retry.
  pause
  exit /b 1
)
echo Python was installed. Close this window, reopen it, and run install.bat again.
pause
exit /b 0

:check_ffmpeg
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo FFmpeg was not found. Attempting installation with winget...
  where winget >nul 2>nul
  if errorlevel 1 (
    echo ERROR: Install FFmpeg and add it to PATH, then run install.bat again.
    pause
    exit /b 1
  )
  winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo ERROR: FFmpeg installation failed. Install FFmpeg manually and retry.
    pause
    exit /b 1
  )
  echo FFmpeg was installed. Close this window, reopen it, and run install.bat again.
  pause
  exit /b 0
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating isolated Python environment...
  py -3.12 -m venv .venv
  if errorlevel 1 goto failed
)

echo Updating pip...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto failed

echo Installing CPU-only PyTorch for this CPU-based app...
.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto failed

echo Installing Auto Dubber libraries. This may take several minutes...
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo.
echo Setup completed successfully. Double-click start.bat to open Auto Dubber.
pause
exit /b 0

:failed
echo.
echo ERROR: Setup did not complete. Check your internet connection and the message above.
pause
exit /b 1
