# Auto Dubber — Chinese and other languages to English

A Windows desktop app that downloads a video (via yt-dlp) or opens a local video, translates speech to English with Faster-Whisper, creates local English speech with Kokoro, and exports a dubbed MP4.

## Supported setup

- Windows 11
- Python 3.12 (installed automatically by `install.bat` when winget is available)
- FFmpeg + FFprobe (installer attempts to install them with winget)
- CPU-only operation; a small Whisper model is recommended for 8 GB RAM
- Internet is needed for package/model downloads and supported video URLs

## Install and run

1. Extract the complete ZIP to a normal folder, for example `C:\AutoDubber`.
2. Double-click `install.bat` and let setup finish. If it installs Python or FFmpeg, close the window, reopen it, and run `install.bat` again.
3. Double-click `start.bat`.

The installer creates a local `.venv` and installs CPU-only PyTorch plus the required libraries. Do not use Python 3.14 for this build; Python 3.12 is the supported target.

## Use

1. Paste a supported video URL, or click **Choose file** to select a local video.
2. Select a US/UK English voice and Whisper accuracy. `small` is a sensible starting point on an 8 GB CPU laptop; `base` is faster, `medium` is slower and uses more memory.
3. Keep text review enabled if you want to correct the translated English before voice generation.
4. Choose whether to remove on-screen text or your own logo. OCR cleanup is optional and slow on CPU; cropping is faster but removes part of the picture.
5. Click **Start Dubbing**. The result is saved under `projects\<video-name>\dubbed.mp4`.

## Voice timing and silence

Faster-Whisper supplies speech segments and word timestamps. The app estimates relative speaking pace within the same video, then adjusts each Kokoro English sentence to fit its original speech interval (up to 1.6x). Long gaps detected between timestamped words are split into separate phrases, so those pauses remain silent. This is approximate: translation length, different language syllable rates, Whisper timing, and TTS phrasing mean it cannot guarantee exact lip-sync. Kokoro generates a selected synthetic English voice; it does not clone the original actor's voice. If an English line is too long for its slot, the app warns that it may be shortened rather than silently letting it overlap the next line.

## Audio and music

- Original dialogue is muted in the output.
- The final export uses a silent background bed when music retention is off, so the mux/export stage does not require an audio stream in the video. A source with no dialogue/audio still cannot be transcribed into English.
- Optional music retention uses Demucs to separate vocals from music. It is disabled by default and can be slow on a CPU. Install it separately with:

  ```powershell
  .venv\Scripts\python.exe -m pip install demucs
  ```

## On-screen text and logo options

- **Cut bottom/top**: crops the selected subtitle strip and scales the picture back up; some image area is lost.
- **AI erase text**: RapidOCR + OpenCV inpainting attempts to remove detected text. It is slow and may leave artifacts, especially on moving or detailed backgrounds.
- **Own logo removal**: FFmpeg delogo is intended only for a logo you own or have permission to remove. It works best for small, fixed corner marks.
- The app does not add captions or a watermark. Soft subtitle streams are not mapped into the final export.

## Troubleshooting

- If the app says FFmpeg is missing, install FFmpeg and reopen the terminal/app so PATH refreshes.
- If library installation fails, check internet access and rerun `install.bat`.
- First launch downloads Whisper/Kokoro model files; allow time for this.
- On 8 GB RAM, close other heavy apps and choose `base` or `small`. Avoid `medium` and OCR cleanup together.
- Use videos you own or have permission to process. Respect the source platform's terms and copyright.

## Developer checks

```powershell
.venv\Scripts\python.exe -m py_compile app.py
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

GitHub Actions runs syntax and unit tests on Windows with Python 3.12.
