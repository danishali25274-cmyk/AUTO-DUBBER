"""
Auto Dubber - paste a Bilibili (or any yt-dlp supported) link, get an English dubbed video.

Pipeline:
  1. yt-dlp        -> download video
  2. ffmpeg        -> extract audio
  3. faster-whisper-> speech to English text WITH timestamps (task="translate",
                      works for Chinese, Korean, Japanese and ~90 other languages)
  4. (optional) You review / fix the English text
  5. Kokoro        -> local English voice for every sentence
  6. ffmpeg        -> match each sentence pace and timing, preserve pauses, mute original voice
  7. Final video   -> projects/<name>/dubbed.mp4

Original voice is muted. Music is kept only if "Keep music" is ticked AND Demucs is installed.
"""
import asyncio
import json
import queue
import re
import subprocess
import sys
import threading
import tkinter as tk
import unicodedata
from pathlib import Path
from tkinter import messagebox, scrolledtext, ttk

BASE = Path(__file__).resolve().parent
PROJECTS = BASE / "projects"
PROJECTS.mkdir(exist_ok=True)

# Kokoro-82M (Apache 2.0, runs locally, safe for commercial/monetized use)
# value = (kokoro voice id, lang_code: "a" = American, "b" = British)
VOICES = {
    "US Female (Heart)": ("af_heart", "a"),
    "US Male (Michael)": ("am_michael", "a"),
    "UK Female (Emma)": ("bf_emma", "b"),
    "UK Male (George)": ("bm_george", "b"),
}
# Remove burned-in foreign subtitles by cutting that strip off and zooming the rest back
# to full size (no blur, no smudges). value = (top fraction, bottom fraction) to cut.
COVER = {
    "Cut bottom 15% (zoom in)": (0, 0.15),
    "Cut bottom 20% (zoom in)": (0, 0.20),
    "Cut bottom 25% (zoom in)": (0, 0.25),
    "Cut top 15% + bottom 20%": (0.15, 0.20),
    "AI: erase ALL text, any language (very slow)": "ocr_all",
    "AI: erase only non-English text (very slow)": "ocr",
    "Off (keep picture as is)": None,
}
# For YOUR OWN videos only: remove a small logo/watermark you put there yourself
# (for example an editing-app watermark). Box = (x, y, width, height) as fractions of the frame.
LOGO = {
    "No logo removal": None,
    "Logo in top-left corner": (0.01, 0.01, 0.20, 0.12),
    "Logo in top-right corner": (0.79, 0.01, 0.20, 0.12),
    "Logo in bottom-left corner": (0.01, 0.87, 0.20, 0.12),
    "Logo in bottom-right corner": (0.79, 0.87, 0.20, 0.12),
}
WHISPER_SIZES = ["base", "small", "medium"]  # base = fastest, medium = best but slow on CPU


# ----------------------------------------------------------------- helpers
def run(cmd, log=None):
    """Run an external media command and report readable errors on Windows."""
    if log:
        log("> " + " ".join(str(c) for c in cmd)[:200])
    try:
        p = subprocess.run(
            [str(c) for c in cmd], capture_output=True, text=True,
            encoding="utf-8", errors="replace", check=False,
        )
    except FileNotFoundError as exc:
        tool = str(cmd[0]) if cmd else "required program"
        raise RuntimeError(f"{tool} was not found. Install FFmpeg and ensure it is on PATH.") from exc
    if p.returncode != 0:
        detail = (p.stderr or p.stdout or "No diagnostic output was returned.").strip()
        raise RuntimeError(detail[-1800:])
    return p.stdout


def media_duration(path):
    out = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
               "-of", "csv=p=0", path])
    return float(out.strip())


def safe_name(text):
    return re.sub(r"[^A-Za-z0-9_-]+", "_", text)[:50].strip("_") or "video"


# ----------------------------------------------------------------- pipeline
def download(url, proj, log):
    log("Step 1/6: Downloading video...")
    run([sys.executable, "-m", "yt_dlp", "-f", "bv*[height<=1080]+ba/b",
         "--merge-output-format", "mp4", "--no-playlist",
         "-o", proj / "original.%(ext)s", url], log)
    video = proj / "original.mp4"
    if video.exists():
        return video
    candidates = sorted(
        p for p in proj.glob("original.*")
        if p.suffix.lower() in {".mp4", ".mkv", ".webm", ".mov"}
    )
    if candidates:
        return candidates[0]
    raise RuntimeError("Download finished, but no supported video file was created.")


def extract_audio(video, proj, log):
    log("Step 2/6: Extracting audio...")
    wav = proj / "audio16k.wav"
    run(["ffmpeg", "-y", "-i", video, "-map", "0:a:0", "-vn", "-ac", "1", "-ar", "16000", wav], log)
    if not wav.exists() or wav.stat().st_size < 1000:
        raise RuntimeError("Audio extraction failed or the video has no usable audio track.")
    return wav


def build_timed_segments(whisper_segments, pause_split=0.55):
    """Convert Whisper output into timed English phrases, preserving long pauses."""
    out = []
    for source in whisper_segments:
        whole_text = (getattr(source, "text", "") or "").strip()
        if not whole_text:
            continue
        words = [w for w in (getattr(source, "words", None) or [])
                 if getattr(w, "start", None) is not None
                 and getattr(w, "end", None) is not None]
        groups = []
        if words:
            current = [words[0]]
            for word in words[1:]:
                if float(word.start) - float(current[-1].end) >= pause_split:
                    groups.append(current)
                    current = [word]
                else:
                    current.append(word)
            groups.append(current)
        else:
            groups = []

        if not groups:
            out.append({"start": round(float(source.start), 3),
                        "end": round(float(source.end), 3), "text": whole_text,
                        "source_rate": None})
            continue

        for group in groups:
            phrase = "".join(str(getattr(w, "word", "")) for w in group).strip()
            if not phrase:
                phrase = whole_text if len(groups) == 1 else ""
            if not phrase:
                continue
            start = float(group[0].start)
            end = float(group[-1].end)
            active_duration = max(0.10, end - start)
            out.append({"start": round(start, 3), "end": round(end, 3),
                        "text": phrase,
                        "source_rate": round(len(group) / active_duration, 3)})

    rates = [x["source_rate"] for x in out if x.get("source_rate") and x["source_rate"] > 0]
    median_rate = sorted(rates)[len(rates) // 2] if rates else None
    for seg in out:
        rate = seg.get("source_rate")
        # Relative pace is compared within this video; the cap avoids extreme TTS rates.
        seg["pace"] = round(max(0.75, min(1.60, rate / median_rate)), 3) if rate and median_rate else 1.0
    return out


def transcribe(wav, model_size, log):
    log(f"Step 3/6: Listening + translating to English (model: {model_size}). "
        "First run downloads the model, please wait...")
    from faster_whisper import WhisperModel
    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segs, info = model.transcribe(
        str(wav), task="translate", vad_filter=True, beam_size=1, word_timestamps=True
    )
    out = build_timed_segments(segs)
    log(f"Detected language: {info.language}. Timed speech phrases found: {len(out)}")
    log("English voice follows detected speech pace; longer pauses between phrases remain silent.")
    return out


def separate_music(wav, proj, log):
    """Optional: keep background music using Demucs. Returns path or None."""
    try:
        import demucs  # noqa: F401
    except ImportError:
        log("Demucs not installed -> music will NOT be kept (original audio fully muted).")
        return None
    log("Separating music from voice with Demucs (slow on CPU)...")
    run([sys.executable, "-m", "demucs", "--two-stems=vocals", "-o", proj / "sep", wav], log)
    found = list((proj / "sep").rglob("no_vocals.wav"))
    if not found:
        log("Demucs did not produce a music track; continuing with the original audio muted.")
        return None
    return found[0]


def make_voice(segments, voice, proj, log):
    log("Step 5/6: Creating English voice for each sentence (Kokoro, local)...")
    import numpy as np
    import soundfile as sf
    from kokoro import KPipeline
    voice_id, lang = voice
    pipe = KPipeline(lang_code=lang)
    tts_dir = proj / "tts"
    tts_dir.mkdir(exist_ok=True)
    for i, seg in enumerate(segments):
        out = tts_dir / f"{i:04d}.wav"
        chunks = []
        for _graphemes, _phonemes, audio in pipe(seg["text"], voice=voice_id):
            if audio is None:
                continue
            if hasattr(audio, "detach"):
                audio = audio.detach().cpu().numpy()
            chunk = np.asarray(audio, dtype="float32").reshape(-1)
            if chunk.size:
                chunks.append(chunk)
        if not chunks:
            raise RuntimeError(f"Kokoro did not generate speech for sentence {i + 1}.")
        sf.write(str(out), np.concatenate(chunks), 24000)
        seg["file"] = str(out)
        seg["dur"] = media_duration(out)
        if i % 10 == 0:
            log(f"  voice {i + 1}/{len(segments)}")
    return segments


def sentence_tempo(segment):
    """Return an FFmpeg atempo factor matching source pace while fitting its slot.

    atempo > 1 speeds up; atempo < 1 slows down. The fit requirement takes
    priority when the translated English line would otherwise overrun.
    """
    slot = max(0.25, float(segment["end"]) - float(segment["start"]) - 0.03)
    pace = max(0.75, min(1.60, float(segment.get("pace", 1.0))))
    fit_tempo = float(segment["dur"]) / slot
    return min(1.60, max(pace, fit_tempo)), slot


def is_foreign(text):
    """True if the text contains any non-English letter (Chinese, Korean, Japanese, Arabic...)."""
    return any(ord(c) > 127 and unicodedata.category(c).startswith("L") for c in text)


def remove_foreign_text(video, proj, log, erase_all=False):
    """OCR video frames and inpaint detected text; return a silent video file."""
    import cv2
    import numpy as np
    from rapidocr_onnxruntime import RapidOCR

    log("AI text removal: this is slow on a CPU laptop and may leave visual artifacts...")
    ocr = RapidOCR()
    cap = cv2.VideoCapture(str(video))
    if not cap.isOpened():
        raise RuntimeError("OpenCV could not open the video for OCR text removal.")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1
    if w < 2 or h < 2:
        cap.release()
        raise RuntimeError("The video dimensions could not be read for OCR text removal.")
    out = proj / "clean_video.mp4"
    ff_log_path = proj / "ocr_ffmpeg.log"
    ff_log_file = ff_log_path.open("wb")
    ff = subprocess.Popen(
        ["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{w}x{h}",
         "-r", str(fps), "-i", "-", "-an", "-c:v", "libx264", "-preset", "veryfast",
         "-crf", "20", "-pix_fmt", "yuv420p", str(out)],
        stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=ff_log_file)
    scale = min(1.0, 960.0 / w)
    step = max(1, int(round(fps / 4)))
    mask, box_area, i = None, None, 0
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if i % step == 0:
                small = cv2.resize(frame, (max(1, int(w * scale)), max(1, int(h * scale)))) if scale < 1 else frame
                result, _ = ocr(small)
                mask = np.zeros((h, w), np.uint8)
                for item in (result or []):
                    box, detected_text = item[0], item[1]
                    if erase_all or is_foreign(detected_text):
                        pts = (np.asarray(box, dtype=np.float32) / scale).astype(np.int32)
                        cv2.fillPoly(mask, [pts], 255)
                if mask.any():
                    mask = cv2.dilate(mask, np.ones((11, 11), np.uint8))
                    ys, xs = np.where(mask > 0)
                    box_area = (max(0, int(ys.min()) - 4), min(h, int(ys.max()) + 5),
                                max(0, int(xs.min()) - 4), min(w, int(xs.max()) + 5))
                else:
                    box_area = None
            if box_area is not None:
                y0, y1, x0, x1 = box_area
                frame[y0:y1, x0:x1] = cv2.inpaint(
                    frame[y0:y1, x0:x1], mask[y0:y1, x0:x1], 3, cv2.INPAINT_TELEA)
            try:
                ff.stdin.write(frame.tobytes())
            except (BrokenPipeError, OSError) as exc:
                raise RuntimeError("FFmpeg stopped while writing the OCR-cleaned video.") from exc
            i += 1
            if i % 300 == 0:
                log(f"  cleaning video {i}/{total} frames")
    finally:
        cap.release()
        if ff.stdin and not ff.stdin.closed:
            try:
                ff.stdin.close()
            except OSError:
                pass
        code = ff.wait()
        ff_log_file.close()
    stderr = ff_log_path.read_text(encoding="utf-8", errors="replace") if ff_log_path.exists() else ""
    if code != 0 or not out.exists() or out.stat().st_size == 0:
        raise RuntimeError("OCR video export failed: " + (stderr[-1200:] or f"FFmpeg exit code {code}"))
    return out


def crop_filter(top, bottom):
    """Cut the top/bottom strips, keep the aspect ratio (trim sides equally), scale back up."""
    keep = 1.0 - top - bottom
    return (f"crop=trunc(iw*{keep}/2)*2:trunc(ih*{keep}/2)*2:"
            f"trunc((iw-iw*{keep})/4)*2:trunc(ih*{top}/2)*2,"
            f"scale=trunc(iw/{keep}/2)*2:trunc(ih/{keep}/2)*2,setsar=1")


def logo_filter(video, area):
    """ffmpeg delogo for a corner box. area = (x, y, w, h) fractions of the frame."""
    out = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
               "stream=width,height", "-of", "csv=p=0:s=x", video])
    W, H = (int(v) for v in out.strip().split("x")[:2])
    fx, fy, fw, fh = area
    x, y = max(1, int(W * fx)), max(1, int(H * fy))
    w, h = max(4, min(int(W * fw), W - x - 2)), max(4, min(int(H * fh), H - y - 2))
    return f"delogo=x={x}:y={y}:w={w}:h={h}"


def mix_and_export(video, segments, bg_path, proj, log, crop=None, logo=None):
    log("Step 6/6: Fitting timing, mixing and exporting...")
    total = media_duration(video)
    if bg_path and Path(bg_path).exists():
        bg_src = Path(bg_path)
        bg_volume = 1.0
    else:
        # Do not depend on the source video having an audio stream. A silent
        # bed guarantees that original dialogue is muted in every case.
        bg_src = proj / "silent_background.wav"
        run(["ffmpeg", "-y", "-f", "lavfi", "-i",
             "anullsrc=channel_layout=stereo:sample_rate=24000", "-t", f"{total:.3f}",
             "-c:a", "pcm_s16le", bg_src], log)
        bg_volume = 1.0

    inputs = [bg_src]
    lines = [f"[0:a]volume={bg_volume}[bg]"]
    labels = ["[bg]"]
    for i, seg in enumerate(segments):
        inputs.append(seg["file"])
        # Fit the translated sentence into the original speech interval, not
        # the gap before the next sentence. This preserves the speaker's pauses.
        requested_tempo, slot = sentence_tempo(seg)
        tempo = requested_tempo
        if seg["dur"] / slot > 1.60:
            log(f"Warning: sentence {i + 1} is too long for its original timing; capped at 1.6x and may be cut short.")
        delay = int(seg["start"] * 1000)
        chain = f"[{i + 1}:a]"
        if abs(tempo - 1.0) > 0.02:
            chain += f"atempo={tempo:.3f},"
        chain += f"atrim=duration={slot:.3f},asetpts=PTS-STARTPTS,adelay={delay}|{delay}[v{i}]"
        lines.append(chain)
        labels.append(f"[v{i}]")
    lines.append("".join(labels) +
                 f"amix=inputs={len(labels)}:normalize=0:duration=first,"
                 f"alimiter=limit=0.95,atrim=0:{total:.2f}[aout]")
    script = proj / "filter.txt"
    script.write_text(";\n".join(lines), encoding="utf-8")

    cmd = ["ffmpeg", "-y"]
    for f in inputs:
        cmd += ["-i", f]
    cmd += ["-filter_complex_script", script, "-map", "[aout]", proj / "dubbed.wav"]
    run(cmd, log)

    final = proj / "dubbed.mp4"
    # Only the video picture and the new English audio are mapped, so any soft
    # subtitle tracks inside the original file are dropped automatically.
    src = video
    if crop in ("ocr", "ocr_all"):
        src = remove_foreign_text(video, proj, log, erase_all=(crop == "ocr_all"))
    vf = []
    if logo:  # YOUR OWN logo/watermark in a corner (ffmpeg delogo)
        vf.append(logo_filter(video, logo))
    if crop and crop not in ("ocr", "ocr_all"):
        vf.append(crop_filter(*crop))
    if vf:
        log("Editing the picture (re-encoding video, this takes a while)...")
        run(["ffmpeg", "-y", "-i", src, "-i", proj / "dubbed.wav",
             "-vf", ",".join(vf), "-map", "0:v", "-map", "1:a",
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
             "-c:a", "aac", "-b:a", "192k", "-shortest", final], log)
    else:
        run(["ffmpeg", "-y", "-i", src, "-i", proj / "dubbed.wav", "-map", "0:v", "-map", "1:a",
             "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", final], log)
    return final


# ----------------------------------------------------------------- GUI
class App:
    def __init__(self, root):
        self.root = root
        root.title("Auto Dubber - Any language to English")
        root.geometry("760x560")
        root.minsize(640, 460)
        self.q = queue.Queue()

        f = ttk.Frame(root, padding=10)
        f.pack(fill="both", expand=True)

        ttk.Label(f, text="Video link (Bilibili etc.) OR your own video file:").pack(anchor="w")
        urlrow = ttk.Frame(f)
        urlrow.pack(fill="x", pady=(0, 8))
        self.url = ttk.Entry(urlrow)
        self.url.pack(side="left", fill="x", expand=True)
        ttk.Button(urlrow, text="Choose file...", command=self.pick_file).pack(side="left", padx=6)

        row = ttk.Frame(f)
        row.pack(fill="x", pady=4)
        ttk.Label(row, text="English voice:").pack(side="left")
        self.voice = ttk.Combobox(row, values=list(VOICES), state="readonly", width=20)
        self.voice.current(0)
        self.voice.pack(side="left", padx=6)
        ttk.Label(row, text="Accuracy:").pack(side="left", padx=(10, 0))
        self.model = ttk.Combobox(row, values=WHISPER_SIZES, state="readonly", width=8)
        self.model.current(1)
        self.model.pack(side="left", padx=6)

        row2 = ttk.Frame(f)
        row2.pack(fill="x", pady=4)
        ttk.Label(row2, text="Remove foreign subtitles on screen:").pack(side="left")
        self.cover = ttk.Combobox(row2, values=list(COVER), state="readonly", width=30)
        self.cover.current(list(COVER).index("Off (keep picture as is)"))
        self.cover.pack(side="left", padx=6)

        row3 = ttk.Frame(f)
        row3.pack(fill="x", pady=4)
        ttk.Label(row3, text="My own logo/watermark:").pack(side="left")
        self.logo = ttk.Combobox(row3, values=list(LOGO), state="readonly", width=30)
        self.logo.current(0)
        self.logo.pack(side="left", padx=6)

        self.review = tk.BooleanVar(value=True)
        self.music = tk.BooleanVar(value=False)
        ttk.Checkbutton(f, text="Let me review/fix the English text before dubbing (recommended)",
                        variable=self.review).pack(anchor="w")
        ttk.Checkbutton(f, text="Keep background music (needs Demucs, much slower)",
                        variable=self.music).pack(anchor="w")

        self.btn = ttk.Button(f, text="Start Dubbing", command=self.start)
        self.btn.pack(pady=8)

        self.logbox = scrolledtext.ScrolledText(f, height=18, state="disabled")
        self.logbox.pack(fill="both", expand=True)
        root.after(200, self.pump)

    def pick_file(self):
        from tkinter import filedialog
        p = filedialog.askopenfilename(filetypes=[("Video", "*.mp4 *.mov *.mkv *.avi *.webm"),
                                                  ("All files", "*.*")])
        if p:
            self.url.delete(0, "end")
            self.url.insert(0, p)

    # thread-safe logging
    def log(self, msg):
        self.q.put(("log", msg))

    def pump(self):
        try:
            while True:
                kind, data = self.q.get_nowait()
                if kind == "log":
                    self.logbox.config(state="normal")
                    self.logbox.insert("end", data + "\n")
                    self.logbox.see("end")
                    self.logbox.config(state="disabled")
                elif kind == "done":
                    self.btn.config(state="normal")
                elif kind == "review":
                    self.open_review(*data)
                elif kind == "error":
                    messagebox.showerror("Error", data)
                elif kind == "success":
                    messagebox.showinfo("Dubbing complete", f"Your English dubbed video is ready:\n{data}")
        except queue.Empty:
            pass
        self.root.after(200, self.pump)

    def start(self):
        url = self.url.get().strip()
        if not url:
            messagebox.showwarning("Link missing", "Please paste a video link or choose a local video file.")
            return
        local = Path(url.strip().strip('"'))
        if not local.is_file() and not re.match(r"^https?://", url, re.IGNORECASE):
            messagebox.showwarning("Invalid input", "Enter a video URL beginning with http:// or https://, or choose a local video file.")
            return
        self.btn.config(state="disabled")
        opts = dict(url=url, voice=VOICES[self.voice.get()], model=self.model.get(),
                    review=self.review.get(), music=self.music.get(),
                    crop=COVER[self.cover.get()], logo=LOGO[self.logo.get()])
        threading.Thread(target=self.worker, args=(opts,), daemon=True).start()

    def worker(self, o):
        try:
            local = Path(o["url"].strip('"'))
            if local.is_file():  # your own camera video
                proj = PROJECTS / safe_name(local.stem)
                proj.mkdir(exist_ok=True)
                video = local
                self.log(f"Using your video file: {local}")
            else:
                proj = PROJECTS / safe_name(o["url"].split("/")[-1] or "video")
                proj.mkdir(exist_ok=True)
                video = download(o["url"], proj, self.log)
            wav = extract_audio(video, proj, self.log)
            segments = transcribe(wav, o["model"], self.log)
            if not segments:
                raise RuntimeError("No speech was found in this video.")
            (proj / "segments.json").write_text(json.dumps(segments, ensure_ascii=False, indent=1),
                                                encoding="utf-8")
            if o["review"]:
                self.log("Step 4/6: Review window opened - fix text if needed, then press Continue.")
                done = threading.Event()
                result = {}
                self.q.put(("review", (segments, result, done)))
                done.wait()
                segments = result.get("segments", segments)
            bg = separate_music(wav, proj, self.log) if o["music"] else None
            segments = make_voice(segments, o["voice"], proj, self.log)
            final = mix_and_export(video, segments, bg, proj, self.log, o["crop"], o["logo"])
            self.log(f"\nDONE! Your dubbed video: {final}")
            self.q.put(("success", str(final)))
        except Exception as e:  # noqa: BLE001
            self.log(f"\nERROR: {e}")
            self.q.put(("error", str(e)[:600]))
        finally:
            self.q.put(("done", None))

    def open_review(self, segments, result, done):
        win = tk.Toplevel(self.root)
        win.title("Review English text (edit the text after the last | only)")
        win.geometry("820x520")
        box = scrolledtext.ScrolledText(win, wrap="word")
        box.pack(fill="both", expand=True, padx=8, pady=8)
        for i, s in enumerate(segments):
            box.insert("end", f"{i} | {s['start']:.1f}-{s['end']:.1f}s | {s['text']}\n")

        def finish():
            new = []
            for line in box.get("1.0", "end").splitlines():
                parts = line.split("|", 2)
                if len(parts) == 3 and parts[0].strip().isdigit():
                    idx = int(parts[0].strip())
                    text = parts[2].strip()
                    if text and idx < len(segments):
                        new.append({**segments[idx], "text": text})
            result["segments"] = new or segments
            win.destroy()
            done.set()

        ttk.Button(win, text="Continue dubbing", command=finish).pack(pady=6)
        win.protocol("WM_DELETE_WINDOW", finish)


if __name__ == "__main__":
    r = tk.Tk()
    App(r)
    r.mainloop()
